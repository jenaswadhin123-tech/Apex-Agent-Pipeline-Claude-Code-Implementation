#!/usr/bin/env bash
# gate.sh — PreToolUse hook for the Task tool.
# Blocks subagent invocations that skip required upstream gates.
# Claude Code passes a JSON payload on stdin describing the tool call.
# Exit code 2 + stderr message = block the call and feed the reason back to Claude.
# Exit code 0 = allow.
#
# Wire this up in .claude/settings.json (see settings.snippet.json in this repo).

set -euo pipefail

STATE_FILE="$(dirname "$0")/../../queue/pipeline_state.json"
INPUT="$(cat)"

# Only gate calls to the Task tool (subagent invocations).
TOOL_NAME=$(echo "$INPUT" | grep -o '"tool_name"[^,}]*' | head -1 | sed 's/.*: *"\(.*\)"/\1/' || true)
if [ "$TOOL_NAME" != "Task" ]; then
  exit 0
fi

# Pull the target subagent name out of the tool_input (best-effort string match;
# swap for `jq` if available in your environment for a more robust parse).
SUBAGENT=$(echo "$INPUT" | grep -o '"subagent_type"[^,}]*' | head -1 | sed 's/.*: *"\(.*\)"/\1/' || true)

if [ -z "$SUBAGENT" ]; then
  exit 0
fi

if ! command -v jq >/dev/null 2>&1; then
  echo "gate.sh: jq not found, cannot verify gate — allowing call. Install jq for real enforcement." >&2
  exit 0
fi

if [ ! -f "$STATE_FILE" ]; then
  echo "gate.sh: no pipeline_state.json found — allowing call (nothing to gate against yet)." >&2
  exit 0
fi

# Feature slug is expected to be passed as an env var by the caller/session,
# or you can grep it out of the prompt text below if you standardize on
# including "slug: <name>" in every subagent prompt.
SLUG="${APEX_FEATURE_SLUG:-}"
if [ -z "$SLUG" ]; then
  echo "gate.sh: APEX_FEATURE_SLUG not set — allowing call (cannot look up gate state)." >&2
  exit 0
fi

get_status() {
  jq -r --arg slug "$SLUG" --arg stage "$1" \
    '.features[$slug].history[] | select(.stage==$stage) | .status' \
    "$STATE_FILE" 2>/dev/null | tail -1
}

case "$SUBAGENT" in
  security)
    for req in frontend backend database; do
      st=$(get_status "$req")
      if [ "$st" != "DONE" ] && [ "$st" != "SKIPPED" ]; then
        echo "BLOCKED: security cannot run — stage '$req' is not DONE for feature '$SLUG' (status: ${st:-not started})." >&2
        exit 2
      fi
    done
    ;;
  qa)
    st=$(get_status "security")
    if [ "$st" != "PASS" ]; then
      echo "BLOCKED: qa cannot run — security stage has not PASSed for feature '$SLUG' (status: ${st:-not started})." >&2
      exit 2
    fi
    ;;
  devops)
    st_sec=$(get_status "security")
    st_qa=$(get_status "qa")
    if [ "$st_sec" != "PASS" ] || [ "$st_qa" != "PASS" ]; then
      echo "BLOCKED: devops cannot run — security (${st_sec:-none}) and qa (${st_qa:-none}) must both be PASS for feature '$SLUG'." >&2
      exit 2
    fi
    ;;
  *)
    exit 0
    ;;
esac

exit 0
